import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-up-photo',
  templateUrl: './up-photo.component.html',
  styleUrls: ['./up-photo.component.scss']
})
export class UpPhotoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
